-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 26, 2023 at 05:06 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `digitalbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `sementics`
--

CREATE TABLE IF NOT EXISTS `sementics` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `skeyword` varchar(100) NOT NULL,
  `count` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `sementics`
--

INSERT INTO `sementics` (`id`, `skeyword`, `count`) VALUES
(2, 'ZC', 5),
(3, 'life 3.0', 3),
(4, 'a', 1),
(5, 'the st', 1),
(6, 'little', 3),
(7, 'alice', 1),
(8, 'stephen', 1),
(9, 'stranger', 1),
(10, '', 2),
(11, 'abc', 1),
(12, 'aaa', 3),
(13, 'life', 1),
(14, 'mrutunjay', 1);
