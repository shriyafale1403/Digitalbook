-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 26, 2023 at 05:07 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `digitalbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `SID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Mob` varchar(15) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `Address` text NOT NULL,
  `Regid` varchar(15) NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`SID`, `Name`, `Email`, `Mob`, `pass`, `Address`, `Regid`) VALUES
(3, 'rutuja patil', 'rutuja@gmail.com', '9022174177', '12345678', 'Kolhapur', '196041'),
(4, 'Shriya Fale', 'shriyafale1403@gmail.com', '9045678901', '12345678', 'Kolhapur', '1'),
(5, 'Pratiksha Rajigare', 'pratikshaarajigare123@gmail.com', '9087654321', '12345678', 'Kolhapur', '4'),
(6, 'Heena Mokashi', 'heenamokashi1234@gmail.com', '9213456789', '12345678', 'Kolhapur', '5'),
(7, 'Devashree Palkar', 'devashree123@gmail.com', '9968743512', '12345678', 'Kolhapur', '6'),
(8, 'Neha Sharma', 'neha@gmail.com', '1234567896', '12345678', 'kolhapur', '2'),
(9, 'Neha kadam', 'nehakadam@gmail.com', '1234567894', '12345678', 'KOLHPA', '20');
